"""
breach-intel-client — Python SDK for the Breach Intel Policy Agent

Zero stdlib dependencies. Drop into any Python AI agent.

    pip install breach-intel-client

Quick start:
    from breach_intel_client import PolicyAgentClient

    client = PolicyAgentClient("http://localhost:8080", agent_id="your-agent-id")
    result = client.emit_llm_response(llm_output, tenant_id="cust-001")
    if result.is_breach:
        print(f"BREACH: {result.breach_types}")
"""

from .client import (
    AsyncPolicyAgentClient,
    BreachRecord,
    EventResult,
    PolicyAgentClient,
    RegistrationResult,
)

__version__ = "0.1.0"
__all__ = [
    "PolicyAgentClient",
    "AsyncPolicyAgentClient",
    "EventResult",
    "BreachRecord",
    "RegistrationResult",
]
