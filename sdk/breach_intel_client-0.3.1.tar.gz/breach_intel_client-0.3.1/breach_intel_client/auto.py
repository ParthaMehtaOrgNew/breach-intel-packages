"""
Breach Intel — Auto-Instrumentation

Passive/automatic monitoring without explicit emit() calls.

Three ways to use:

1. @monitor decorator — wrap any tool function
   ─────────────────────────────────────────
   from breach_intel_client import PolicyAgentClient, monitor

   client = PolicyAgentClient("http://localhost:8080", agent_id="my-agent")

   @monitor(client)
   def search_database(query: str) -> dict:
       ...  # auto-emits "tool_call" event every time this is called

   @monitor(client)
   async def fetch_records(user_id: str) -> list:
       ...  # works for async functions too

2. LangChainBreachHandler — drop into any LangChain agent/chain
   ──────────────────────────────────────────────────────────────
   from breach_intel_client import PolicyAgentClient, LangChainBreachHandler

   client = PolicyAgentClient("http://localhost:8080", agent_id="my-agent")
   handler = LangChainBreachHandler(client)

   agent = AgentExecutor(llm=llm, tools=tools, callbacks=[handler])
   # Every LLM response and tool call is now auto-monitored.

3. auto_monitor context manager — batch-wrap multiple functions
   ─────────────────────────────────────────────────────────────
   from breach_intel_client import PolicyAgentClient, auto_monitor

   client = PolicyAgentClient("http://localhost:8080", agent_id="my-agent")

   with auto_monitor(client, [send_email, read_file, call_api]) as patched:
       # Inside here, all three functions emit events automatically
       agent.run(task)
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import logging
from contextlib import contextmanager
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import PolicyAgentClient

logger = logging.getLogger(__name__)


# ─── @monitor decorator ────────────────────────────────────────────────────────


def monitor(
    client: "PolicyAgentClient",
    tenant_id: Optional[str] = None,
    silent: bool = True,
):
    """
    Decorator that auto-instruments a function as a tool_call event.

    Works with both sync and async functions.
    If emission fails and silent=True (default), the original function still runs.

    Usage:
        @monitor(client)
        def search_database(query: str) -> dict:
            ...

        @monitor(client, tenant_id="customer-001")
        async def fetch_user(user_id: str):
            ...
    """

    def decorator(func: Callable) -> Callable:
        tool_name = func.__name__

        def _build_args_dict(*args, **kwargs) -> Dict[str, Any]:
            """Bind call args to parameter names for a readable payload."""
            sig = inspect.signature(func)
            try:
                bound = sig.bind(*args, **kwargs)
                bound.apply_defaults()
                return dict(bound.arguments)
            except Exception:
                return {"args": list(args), "kwargs": kwargs}

        def _emit(args_dict: Dict[str, Any]) -> None:
            try:
                client.emit_tool_call(tool_name, args_dict, tenant_id=tenant_id)
            except Exception as e:
                if not silent:
                    raise
                logger.debug(f"breach-intel: silent emit error for {tool_name}: {e}")

        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                _emit(_build_args_dict(*args, **kwargs))
                return await func(*args, **kwargs)
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                _emit(_build_args_dict(*args, **kwargs))
                return func(*args, **kwargs)
            return sync_wrapper

    return decorator


# ─── auto_monitor context manager ─────────────────────────────────────────────


@contextmanager
def auto_monitor(
    client: "PolicyAgentClient",
    functions: List[Callable],
    tenant_id: Optional[str] = None,
    silent: bool = True,
):
    """
    Context manager that temporarily wraps a list of functions with monitoring.
    Original functions are restored when the context exits.

    Usage:
        with auto_monitor(client, [send_email, read_file, call_api]):
            agent.run(task)
    """
    originals: Dict[str, tuple] = {}

    try:
        for func in functions:
            wrapped = monitor(client, tenant_id=tenant_id, silent=silent)(func)
            module = inspect.getmodule(func)
            if module is not None:
                name = func.__name__
                originals[name] = (module, name, getattr(module, name, None))
                setattr(module, name, wrapped)

        yield

    finally:
        # Restore all original functions
        for name, (module, attr, original) in originals.items():
            if original is not None:
                setattr(module, attr, original)
            else:
                delattr(module, attr)


# ─── LangChain callback handler ───────────────────────────────────────────────

try:
    from langchain.callbacks.base import BaseCallbackHandler  # type: ignore
    from langchain.schema import LLMResult  # type: ignore

    class LangChainBreachHandler(BaseCallbackHandler):
        """
        LangChain callback handler that auto-emits every LLM response
        and tool call to the Breach Intel Policy Agent.

        Usage:
            handler = LangChainBreachHandler(client, tenant_id="cust-001")
            agent = AgentExecutor(llm=llm, tools=tools, callbacks=[handler])
        """

        def __init__(
            self,
            client: "PolicyAgentClient",
            tenant_id: Optional[str] = None,
            silent: bool = True,
        ):
            super().__init__()
            self.client = client
            self.tenant_id = tenant_id
            self.silent = silent

        def _safe_emit(self, event_type: str, payload: Dict[str, Any]) -> None:
            try:
                self.client.emit(event_type, payload, tenant_id=self.tenant_id)
            except Exception as e:
                if not self.silent:
                    raise
                logger.debug(f"breach-intel LangChain handler error: {e}")

        def on_llm_end(self, response: LLMResult, **kwargs) -> None:
            """Auto-capture every LLM output."""
            for generations in response.generations:
                for gen in generations:
                    text = getattr(gen, "text", str(gen))
                    self._safe_emit("llm_response", {"text": text})

        def on_tool_start(
            self, serialized: Dict[str, Any], input_str: str, **kwargs
        ) -> None:
            """Auto-capture every tool invocation."""
            tool_name = serialized.get("name", "unknown_tool")
            self._safe_emit(
                "tool_call",
                {"tool": tool_name, "args": {"input": input_str}},
            )

        def on_tool_end(self, output: str, **kwargs) -> None:
            """Optionally capture tool output (useful for exfiltration detection)."""
            # Only emit if the output looks like it could contain sensitive data
            # (avoids spamming the policy agent with every clean result)
            if output and len(output) > 10:
                self._safe_emit("action", {"tool_output": output[:2000]})

        def on_agent_action(self, action: Any, **kwargs) -> None:
            """Capture the agent's decision to use a tool."""
            tool = getattr(action, "tool", None)
            tool_input = getattr(action, "tool_input", None)
            if tool:
                self._safe_emit(
                    "tool_call",
                    {"tool": tool, "args": tool_input or {}},
                )

except ImportError:
    # LangChain not installed — LangChainBreachHandler unavailable
    class LangChainBreachHandler:  # type: ignore
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "LangChain is not installed. "
                "Run: pip install langchain"
            )


# ─── Passive auto-attach ─────────────────────────────────────────────────────

_global_client: Optional["PolicyAgentClient"] = None


def get_client() -> Optional["PolicyAgentClient"]:
    """Return the globally auto-attached client, or None."""
    return _global_client


def auto_attach(
    url: Optional[str] = None,
    token: Optional[str] = None,
    agent_id: Optional[str] = None,
    vertical: str = "fintech",
    silent: bool = True,
) -> Optional["PolicyAgentClient"]:
    """
    Create a global PolicyAgentClient and hook into all detected frameworks.

    If url is not provided, reads BREACH_INTEL_URL from environment.
    If token is not provided, reads BREACH_INTEL_TOKEN from environment.
    If agent_id is not provided, generates one from hostname + PID.

    Returns the client instance, or None if no URL is configured.
    """
    import os
    import socket
    global _global_client

    url = url or os.environ.get("BREACH_INTEL_URL", "")
    if not url:
        return None

    token = token or os.environ.get("BREACH_INTEL_TOKEN", "")

    if not agent_id:
        agent_id = f"auto-{socket.gethostname()}-{os.getpid()}"

    from .client import PolicyAgentClient
    _global_client = PolicyAgentClient(
        base_url=url,
        agent_id=agent_id,
        vertical=vertical,
        api_token=token,
        silent=silent,
    )

    _attach_langchain(_global_client)
    _attach_openai(_global_client)
    _attach_anthropic(_global_client)

    # Auto-register with the policy agent so it knows about this process
    _auto_register(_global_client, agent_id)

    logger.info(f"breach-intel: auto-attached to {url} agent_id={agent_id}")
    return _global_client


def _auto_register(client: "PolicyAgentClient", agent_id: str) -> None:
    """Auto-register this process with the policy agent, reporting detected frameworks."""
    import os
    import sys

    # Detect which AI frameworks are available in this process
    capabilities = []
    for mod_name, cap in [
        ("openai", "openai_chat"),
        ("anthropic", "anthropic_messages"),
        ("langchain_core", "langchain_invoke"),
        ("langchain", "langchain_invoke"),
    ]:
        if mod_name in sys.modules:
            if cap not in capabilities:
                capabilities.append(cap)

    # Derive a human-readable agent name from the running script
    script = os.path.basename(sys.argv[0]) if sys.argv else "unknown"
    agent_name = f"auto:{script}" if script and script != "-c" else f"auto:{agent_id}"

    try:
        client.register(
            agent_name=agent_name,
            owner_id="default",
            declared_capabilities=capabilities,
            metadata={"auto_registered": True, "pid": os.getpid()},
        )
        logger.info(f"breach-intel: auto-registered {agent_name} caps={capabilities}")
    except Exception as e:
        logger.debug(f"breach-intel: auto-register failed (non-fatal): {e}")


def _attach_langchain(client: "PolicyAgentClient") -> None:
    """If langchain-core is installed, monkey-patch BaseChatModel to auto-capture LLM responses."""
    try:
        from langchain_core.language_models.chat_models import BaseChatModel  # type: ignore
    except ImportError:
        return

    # Guard against double-patching
    if getattr(BaseChatModel, "_breach_intel_patched", False):
        return

    _original_invoke = BaseChatModel.invoke

    @functools.wraps(_original_invoke)
    def _patched_invoke(self, input, config=None, **kwargs):
        response = _original_invoke(self, input, config=config, **kwargs)
        try:
            text = response.content if hasattr(response, "content") else str(response)
            if text:
                client.emit("llm_response", {"text": str(text)[:4000]})
        except Exception:
            pass  # never break the caller
        return response

    BaseChatModel.invoke = _patched_invoke

    # Patch async variant too
    if hasattr(BaseChatModel, "ainvoke"):
        _original_ainvoke = BaseChatModel.ainvoke

        @functools.wraps(_original_ainvoke)
        async def _patched_ainvoke(self, input, config=None, **kwargs):
            response = await _original_ainvoke(self, input, config=config, **kwargs)
            try:
                text = response.content if hasattr(response, "content") else str(response)
                if text:
                    client.emit("llm_response", {"text": str(text)[:4000]})
            except Exception:
                pass
            return response

        BaseChatModel.ainvoke = _patched_ainvoke

    BaseChatModel._breach_intel_patched = True
    logger.info("breach-intel: LangChain BaseChatModel.invoke patched")


def _attach_openai(client: "PolicyAgentClient") -> None:
    """If openai is already imported, monkey-patch chat completions."""
    try:
        import openai  # type: ignore
        if not hasattr(openai, "chat"):
            return

        _original_create = openai.chat.completions.create

        @functools.wraps(_original_create)
        def _patched_create(*args, **kwargs):
            response = _original_create(*args, **kwargs)
            try:
                for choice in response.choices:
                    text = choice.message.content or ""
                    if text:
                        client.emit("llm_response", {"text": text[:4000]})
            except Exception:
                pass  # never break the caller
            return response

        openai.chat.completions.create = _patched_create
        logger.info("breach-intel: OpenAI chat.completions.create patched")
    except (ImportError, AttributeError):
        pass


def _attach_anthropic(client: "PolicyAgentClient") -> None:
    """If anthropic SDK is installed, monkey-patch messages.create to auto-capture LLM responses."""
    try:
        import anthropic  # type: ignore  # noqa: F401
        from anthropic.resources.messages import Messages  # type: ignore
    except ImportError:
        return

    # Guard against double-patching
    if getattr(Messages, "_breach_intel_patched", False):
        return

    _original_create = Messages.create

    @functools.wraps(_original_create)
    def _patched_create(self, *args, **kwargs):
        response = _original_create(self, *args, **kwargs)
        try:
            # Anthropic returns Message with content: List[ContentBlock]
            for block in response.content:
                if hasattr(block, "text") and block.text:
                    client.emit("llm_response", {"text": block.text[:4000]})
                    break  # emit once per response, not per block
        except Exception:
            pass  # never break the caller
        return response

    Messages.create = _patched_create

    # Patch async variant
    try:
        from anthropic.resources.messages import AsyncMessages  # type: ignore

        if not getattr(AsyncMessages, "_breach_intel_patched", False):
            _original_async_create = AsyncMessages.create

            @functools.wraps(_original_async_create)
            async def _patched_async_create(self, *args, **kwargs):
                response = await _original_async_create(self, *args, **kwargs)
                try:
                    for block in response.content:
                        if hasattr(block, "text") and block.text:
                            client.emit("llm_response", {"text": block.text[:4000]})
                            break
                except Exception:
                    pass
                return response

            AsyncMessages.create = _patched_async_create
            AsyncMessages._breach_intel_patched = True
    except (ImportError, AttributeError):
        pass

    Messages._breach_intel_patched = True
    logger.info("breach-intel: Anthropic Messages.create patched")
